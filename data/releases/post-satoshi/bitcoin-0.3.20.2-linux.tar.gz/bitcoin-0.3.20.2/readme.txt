Bitcoin 0.3.20.2 BETA

Copyright (c) 2009-2011 Bitcoin Developers
Distributed under the MIT/X11 software license, see the accompanying
file license.txt or http://www.opensource.org/licenses/mit-license.php.
This product includes software developed by the OpenSSL Project for use in
the OpenSSL Toolkit (http://www.openssl.org/).  This product includes
cryptographic software written by Eric Young (eay@cryptsoft.com).


Intro
-----
Bitcoin is a free open source peer-to-peer electronic cash system that is
completely decentralized, without the need for a central server or trusted
parties.  Users hold the crypto keys to their own money and transact directly
with each other, with the help of a P2P network to check for double-spending.


Setup
-----
Unpack the files into a directory and run:
 bin/32/bitcoin (GUI, 32-bit)
 bin/32/bitcoind (headless, 32-bit)
 bin/64/bitcoin (GUI, 64-bit)
 bin/64/bitcoind (headless, 64-bit)

See the documentation at the bitcoin wiki:
  https://en.bitcoin.it/wiki/Main_Page

... for help and more information.
